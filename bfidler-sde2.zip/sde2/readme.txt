Contents:
which_shape.caml
readme.txt
bfidler-sde2.log

On my honor, I have neither given nor received aid on this exam.
