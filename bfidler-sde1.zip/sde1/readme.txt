This archive contains what_shape.pro, sde1.log, and this readme.
what_shape.pro contains predicates to parse squares, rectangles, and triangles.
Sde1.log demonstrates the use of these predicates.

On my honor I have neither given nor received aid on this assignment.
SIGN: Brayden Fidler
